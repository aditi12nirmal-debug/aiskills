import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Bot,
  BriefcaseBusiness,
  Check,
  ChevronDown,
  ChevronRight,
  CircleCheck,
  CircleDot,
  Compass,
  Crosshair,
  Database,
  ExternalLink,
  FileText,
  GitBranch,
  Globe2,
  Layers3,
  LineChart,
  MapPin,
  Menu,
  MessageCircle,
  Minus,
  Network,
  Plus,
  Radar,
  Rocket,
  Search,
  Sparkles,
  Target,
  Terminal,
  UploadCloud,
  X,
  Zap,
} from "lucide-react";

const skills = [
  { name: "Python", current: 90, required: 80, status: "STRONG", priority: "Foundation", color: "#9be56d" },
  { name: "SQL", current: 72, required: 72, status: "GOOD", priority: "Foundation", color: "#70d9ce" },
  { name: "FastAPI", current: 65, required: 75, status: "GOOD", priority: "High", color: "#7cc9ff" },
  { name: "Machine Learning", current: 54, required: 80, status: "PARTIAL", priority: "High", color: "#ffc78d" },
  { name: "LLMs & RAG", current: 32, required: 75, status: "HIGH GAP", priority: "High", color: "#d8a8ff" },
  { name: "Docker", current: 31, required: 70, status: "HIGH GAP", priority: "High", color: "#7cc9ff" },
  { name: "Cloud", current: 28, required: 65, status: "HIGH GAP", priority: "High", color: "#70d9ce" },
  { name: "MLOps", current: 18, required: 70, status: "CRITICAL GAP", priority: "Critical", color: "#ff977a" },
];

const intelligenceCards = [
  { icon: UploadCloud, id: "01", title: "Resume analyzer", copy: "Upload your resume and extract skills, experience, projects, education, and technologies.", meta: "5 min scan" },
  { icon: LineChart, id: "02", title: "Skill gap analyzer", copy: "Compare your current proficiency against the exact requirements of a target role.", meta: "Role-aware" },
  { icon: MapPin, id: "03", title: "AI roadmap", copy: "Get a personalized sequence of skills to learn next, with dependencies and effort mapped.", meta: "Adaptive path" },
  { icon: Rocket, id: "04", title: "Project recommender", copy: "Build projects specifically designed to close your biggest, most valuable gaps.", meta: "Portfolio-ready" },
  { icon: Radar, id: "05", title: "Future skills", copy: "Discover emerging skills that could matter for your target career before they become obvious.", meta: "Signal-led" },
  { icon: BriefcaseBusiness, id: "06", title: "Job matching", copy: "Find opportunities that match your current skill profile, location, and trajectory.", meta: "Live fit" },
  { icon: Bot, id: "07", title: "AI career coach", copy: "Ask what to learn next, why a gap matters, or which project will move your profile furthest.", meta: "Always on" },
];

const roadmap = [
  { id: "01", title: "Foundation", skills: ["Machine Learning", "Model Evaluation", "Feature Engineering"], duration: "4 weeks", difficulty: "Intermediate", project: "Fraud detection model" },
  { id: "02", title: "Production AI", skills: ["FastAPI", "Docker", "Model Deployment"], duration: "3 weeks", difficulty: "Intermediate", project: "Inference API" },
  { id: "03", title: "MLOps", skills: ["CI/CD", "Monitoring", "Model Lifecycle"], duration: "5 weeks", difficulty: "Advanced", project: "Model ops platform" },
  { id: "04", title: "Generative AI", skills: ["LLMs", "RAG", "Vector Databases"], duration: "4 weeks", difficulty: "Advanced", project: "RAG career coach" },
  { id: "05", title: "Cloud", skills: ["AWS / GCP", "Scalable Inference", "AI Observability"], duration: "3 weeks", difficulty: "Advanced", project: "Cloud deployment" },
];

const projects = [
  { id: "01", title: "Production ML Deployment Platform", tags: ["Docker", "FastAPI", "MLOps", "Cloud"], difficulty: "Advanced", time: "5–6 weeks", description: "Ship a monitored inference service with CI/CD, containerization, model versioning, and cloud deployment." },
  { id: "02", title: "RAG-Based Career Coach", tags: ["LLMs", "RAG", "Vector DB", "FastAPI"], difficulty: "Intermediate", time: "3–4 weeks", description: "Build a grounded assistant that retrieves role requirements and gives evidence-backed career guidance." },
  { id: "03", title: "AI Resume Intelligence System", tags: ["Python", "NLP", "LLMs", "Postgres"], difficulty: "Advanced", time: "5–6 weeks", description: "Create a structured resume parser that maps evidence to skills, outcomes, and target-role requirements." },
];

const jobs = [
  { role: "AI Engineer", company: "TechNova", place: "Remote", match: 84, matched: ["Python", "Machine Learning", "FastAPI"], missing: ["MLOps", "AWS"] },
  { role: "ML Engineer", company: "DataForge", place: "Bengaluru", match: 78, matched: ["Python", "SQL", "Machine Learning"], missing: ["Docker", "Cloud"] },
  { role: "Machine Learning Engineer", company: "NeuralStack", place: "Remote", match: 81, matched: ["Python", "FastAPI", "SQL"], missing: ["MLOps", "LLMs"] },
  { role: "AI Platform Engineer", company: "CloudWorks", place: "Hyderabad", match: 73, matched: ["Python", "Docker"], missing: ["Cloud", "MLOps", "Kubernetes"] },
];

const futureSkills = ["Agentic AI", "RAG", "LLM Evaluation", "AI Observability", "Multimodal AI", "AI Security", "Vector Databases", "Model Serving"];

const networkNodes = [
  { id: "python", label: "Python", x: 20, y: 48, value: "90%", tone: "strong", detail: "Your strongest anchor. Python unlocks every path in the current map." },
  { id: "ml", label: "Machine Learning", x: 39, y: 32, value: "54%", tone: "warm", detail: "Partial proficiency. Closing this gap makes LLM and production work easier." },
  { id: "rag", label: "LLMs & RAG", x: 63, y: 19, value: "32%", tone: "violet", detail: "High-growth skill cluster with direct relevance to AI product roles." },
  { id: "fastapi", label: "FastAPI", x: 38, y: 68, value: "65%", tone: "cyan", detail: "A useful bridge from notebooks to production-ready services." },
  { id: "docker", label: "Docker", x: 61, y: 67, value: "31%", tone: "cyan", detail: "A high-value missing link for deploying and demonstrating your work." },
  { id: "mlops", label: "MLOps", x: 80, y: 69, value: "18%", tone: "critical", detail: "Critical gap. This is the constraint currently capping your readiness score." },
  { id: "cloud", label: "Cloud", x: 82, y: 42, value: "28%", tone: "cyan", detail: "Required to scale your models and build operational confidence." },
  { id: "sql", label: "SQL", x: 20, y: 78, value: "72%", tone: "strong", detail: "Good working proficiency that supports the whole profile." },
];

const coachAnswers: Record<string, string> = {
  "What should I learn next?": "MLOps first. It is your largest role-critical gap and it unlocks Docker, Cloud, and confident production delivery. Start with model versioning and monitoring.",
  "Why is MLOps my biggest gap?": "Your target AI Engineer role weights operational ownership heavily. You are at 18% proficiency against an estimated 70% requirement, creating a 52-point gap.",
  "Which project should I build?": "Build the Production ML Deployment Platform. It bundles your highest-priority gaps into one proof-of-work artifact: Docker, FastAPI, MLOps, and Cloud.",
  "Should I learn AWS or GCP?": "Either is viable. Start with AWS if you want the broadest role coverage; choose GCP if your target companies are strongly data-platform oriented. The first step is portable either way.",
};

const simulationLift: Record<string, number> = { MLOps: 9, AWS: 5, Docker: 4, RAG: 4, LLMs: 3, Kubernetes: 3, "CI/CD": 3 };
const getSimulatedScore = (items: string[]) => 72 + items.reduce((score, skill) => score + (simulationLift[skill] ?? 0), 0);

type CareerAnalysis = {
  documentId?: number;
  summary: string;
  roleFitScore: number;
  strengths: string[];
  gaps: Array<{ skill: string; current: number; required: number; whyItMatters: string }>;
  nextSteps: string[];
  roleDirections: Array<{ role: string; location: string; chance: string; why: string }>;
};

type ComparisonResult = {
  summary: string;
  winner: "resume-a" | "resume-b" | "tie";
  winnerReason: string;
  changes: Array<{ category: string; resumeA: string; resumeB: string; advantage: "resume-a" | "resume-b" | "tie" }>;
  nextSteps: string[];
  left: { id: number; fileName: string };
  right: { id: number; fileName: string };
};

function clamp(value: number, min = 0, max = 1) { return Math.min(max, Math.max(min, value)); }
function smoothstep(value: number) { const x = clamp(value); return x * x * (3 - 2 * x); }
function lerp(a: number, b: number, t: number) { return a + (b - a) * clamp(t); }
function segmentInOut(progress: number, start: number, end: number) { return smoothstep((progress - start) / (end - start)); }

function SectionLabel({ index, eyebrow, children }: { index: string; eyebrow: string; children: React.ReactNode }) {
  return <div className="section-label"><span>{index}</span><span className="section-label-dot" /><span>{eyebrow}</span><strong>{children}</strong></div>;
}

function ProgressBar({ value, required, color = "#9be56d" }: { value: number; required?: number; color?: string }) {
  return <div className="progress-track"><span className="progress-required" style={{ left: `${required ?? value}%` }} /><span className="progress-fill" style={{ width: `${value}%`, background: color }} /></div>;
}

export default function Home() {
  // The useAuth hook provides authentication state.
  // To implement login/logout, call logout(), or start login from an event
  // handler: onClick={() => startLogin()} (imported from "@/const"). Never call
  // startLogin() during render (no href={startLogin()}) — it mints a one-time
  // nonce cookie and must run only at the moment of navigation.
  let { user, loading, error, isAuthenticated, logout } = useAuth();
  const snapshotQuery = trpc.career.snapshot.useQuery(undefined, { enabled: Boolean(user) });
  const profileSaveMutation = trpc.career.saveProfile.useMutation();
  const roadmapMutation = trpc.career.setRoadmapProgress.useMutation();
  const projectMutation = trpc.career.setProjectProgress.useMutation();
  const simulatorMutation = trpc.career.saveSimulator.useMutation();
  const assistantMutation = trpc.assistant.ask.useMutation({
    onSuccess: (result) => setAssistantAnswerText(result.answer),
  });
  const documentHistoryQuery = trpc.career.documents.useQuery(undefined, { enabled: Boolean(user) });
  const documentMutation = trpc.career.analyzeDocument.useMutation({
    onSuccess: (result) => { setAnalysisResult({ ...(result.analysis as CareerAnalysis), documentId: result.documentId }); setJobSearchRole(result.targetRole); documentHistoryQuery.refetch(); },
    onError: (uploadError) => setUploadError(uploadError.message),
  });
  const compareMutation = trpc.career.compareDocuments.useMutation();

  const [progress, setProgress] = useState(0);
  const [selectedSkill, setSelectedSkill] = useState(skills[7]);
  const [activeCard, setActiveCard] = useState(0);
  const [openRoadmap, setOpenRoadmap] = useState<string | null>("03");
  const [completedRoadmap, setCompletedRoadmap] = useState<string[]>([]);
  const [selectedNode, setSelectedNode] = useState(networkNodes[5]);
  const [networkZoom, setNetworkZoom] = useState(1);
  const [networkPan, setNetworkPan] = useState({ x: 0, y: 0 });
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [addedProjects, setAddedProjects] = useState<string[]>([]);
  const [selectedJob, setSelectedJob] = useState(jobs[0]);
  const [selectedLiveJobIndex, setSelectedLiveJobIndex] = useState(0);
  const [simSkills, setSimSkills] = useState<string[]>([]);
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [assistantQuestion, setAssistantQuestion] = useState("What should I learn next?");
  const [assistantAnswerText, setAssistantAnswerText] = useState("");
  const [targetRole, setTargetRole] = useState("AI Engineer");
  const [jobSearchRole, setJobSearchRole] = useState("AI Engineer");
  const [uploadedFileName, setUploadedFileName] = useState("");
  const [analysisResult, setAnalysisResult] = useState<CareerAnalysis | null>(null);
  const [selectedHistoryIds, setSelectedHistoryIds] = useState<number[]>([]);
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult | null>(null);
  const [uploadError, setUploadError] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [pointer, setPointer] = useState({ x: 0, y: 0 });
  const stageRef = useRef<HTMLDivElement>(null);
  const networkRef = useRef<HTMLDivElement>(null);
  const documentInputRef = useRef<HTMLInputElement>(null);
  const liveJobsQuery = trpc.career.liveJobs.useQuery({
    targetRole: jobSearchRole,
    skills: analysisResult?.gaps.map((gap) => gap.skill) ?? skills.filter((skill) => skill.current < skill.required).map((skill) => skill.name),
    location: "Remote",
  }, { staleTime: 5 * 60 * 1000, retry: 1 });
  const stateHydratedRef = useRef(false);
  const profileSeededRef = useRef(false);

  useEffect(() => {
    const onScroll = () => {
      const height = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(height > 0 ? window.scrollY / height : 0);
    };
    const onPointer = (event: PointerEvent) => setPointer({ x: event.clientX / window.innerWidth - 0.5, y: event.clientY / window.innerHeight - 0.5 });
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("pointermove", onPointer, { passive: true });
    onScroll();
    return () => { window.removeEventListener("scroll", onScroll); window.removeEventListener("pointermove", onPointer); };
  }, []);

  useEffect(() => {
    const elements = document.querySelectorAll<HTMLElement>("[data-reveal]");
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) entry.target.classList.add("revealed");
    }), { threshold: 0.14 });
    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!user || snapshotQuery.isLoading || !snapshotQuery.data || stateHydratedRef.current) return;
    stateHydratedRef.current = true;
    setCompletedRoadmap(snapshotQuery.data.roadmap.filter((item) => item.completed === 1).map((item) => item.phaseId));
    setAddedProjects(snapshotQuery.data.projects.filter((item) => item.completed === 1).map((item) => item.projectId));
    const latestSimulation = snapshotQuery.data.simulations[0];
    if (latestSimulation) {
      try { setSimSkills(JSON.parse(latestSimulation.selectedSkillsJson)); } catch { /* keep the default */ }
    }
  }, [user, snapshotQuery.data, snapshotQuery.isLoading]);

  useEffect(() => {
    if (!user || snapshotQuery.isLoading || snapshotQuery.data?.profile || profileSeededRef.current) return;
    profileSeededRef.current = true;
    profileSaveMutation.mutate({
      name: "Alex Sharma",
      targetRole: "AI Engineer",
      experience: "2 Years",
      readinessScore: 72,
      futureScore: 68,
      skills: skills.map((skill) => ({ name: skill.name, proficiency: skill.current })),
    });
  }, [user, snapshotQuery.data, snapshotQuery.isLoading]);

  const simulatedScore = useMemo(() => getSimulatedScore(simSkills), [simSkills]);
  const currentScene = Math.round(progress * 10);
  const profileLift = lerp(0, 18, segmentInOut(progress, 0.1, 0.3));

  const scrollTo = (id: string) => { document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }); setMenuOpen(false); };
  const toggleSimSkill = (skill: string) => setSimSkills((current) => {
    const next = current.includes(skill) ? current.filter((item) => item !== skill) : [...current, skill];
    if (user) simulatorMutation.mutate({ selectedSkills: next, simulatedScore: getSimulatedScore(next) });
    return next;
  });
  const toggleRoadmapComplete = (id: string) => setCompletedRoadmap((current) => {
    const completed = !current.includes(id);
    const next = completed ? [...current, id] : current.filter((item) => item !== id);
    if (user) roadmapMutation.mutate({ phaseId: id, completed });
    return next;
  });
  const toggleProject = (id: string) => setAddedProjects((current) => {
    const completed = !current.includes(id);
    const next = completed ? [...current, id] : current.filter((item) => item !== id);
    if (user) projectMutation.mutate({ projectId: id, completed });
    return next;
  });
  const submitAssistantQuestion = (question: string) => {
    const trimmed = question.trim();
    if (!trimmed) return;
    setAssistantQuestion(trimmed);
    setAssistantAnswerText("");
    assistantMutation.reset();
    let persistedContext = "";
    const savedProfile = snapshotQuery.data?.profile;
    if (savedProfile) {
      try {
        const savedSkills = JSON.parse(savedProfile.skillsJson) as Array<{ name: string; proficiency: number }>;
        persistedContext = `Saved profile target role: ${savedProfile.targetRole}. Experience: ${savedProfile.experience}. Readiness: ${savedProfile.readinessScore}%. Future score: ${savedProfile.futureScore}%. Skills: ${savedSkills.map((skill) => `${skill.name} ${skill.proficiency}%`).join(", ")}.`;
      } catch { persistedContext = `Saved profile target role: ${savedProfile.targetRole}. Readiness: ${savedProfile.readinessScore}%.`; }
    }
    const liveProfileContext = analysisResult
      ? `Target role: ${targetRole}. Directional fit: ${analysisResult.roleFitScore}%. Summary: ${analysisResult.summary}. Strengths: ${analysisResult.strengths.join(", ")}. Gaps: ${analysisResult.gaps.map((gap) => `${gap.skill} (${gap.current}% current vs ${gap.required}% required)`).join(", ")}. Next steps: ${analysisResult.nextSteps.join("; ")}.`
      : persistedContext || `Current target role: ${targetRole}. No document analysis is loaded; answer generally and do not invent a user name.`;
    assistantMutation.mutate({ question: trimmed, profileContext: liveProfileContext });
  };
  const assistantAnswer = assistantAnswerText || coachAnswers[assistantQuestion] || "Ask me anything about your career route, skill gaps, projects, jobs, or what to learn next.";
  const handleDocumentUpload = (file?: File) => {
    if (!file) return;
    setUploadedFileName(file.name);
    setUploadError("");
    setAnalysisResult(null);
    if (file.size > 10 * 1024 * 1024) {
      setUploadError("Please upload a file smaller than 10 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result ?? "");
      const fileBase64 = dataUrl.includes(",") ? dataUrl.split(",")[1] : dataUrl;
      documentMutation.mutate({ fileName: file.name, mimeType: file.type || "application/octet-stream", fileBase64, targetRole });
    };
    reader.onerror = () => setUploadError("I couldn't read that file. Try exporting it as PDF, DOCX, XLSX, PPTX, or plain text.");
    reader.readAsDataURL(file);
  };
  const toggleHistoryDocument = (id: number) => setSelectedHistoryIds((current) => current.includes(id) ? current.filter((item) => item !== id) : current.length >= 2 ? [current[1], id] : [...current, id]);
  const compareSelectedDocuments = () => {
    if (selectedHistoryIds.length !== 2) return;
    setComparisonResult(null);
    compareMutation.mutate({ leftDocumentId: selectedHistoryIds[0], rightDocumentId: selectedHistoryIds[1], targetRole }, { onSuccess: (result) => setComparisonResult(result as ComparisonResult) });
  };
  const liveJobs = liveJobsQuery.data?.jobs ?? [];
  const activeLiveJob = liveJobs[selectedLiveJobIndex] ?? liveJobs[0];
  const handleNetworkWheel = (event: React.WheelEvent) => { event.preventDefault(); setNetworkZoom((zoom) => clamp(zoom - event.deltaY * 0.001, 0.75, 1.8)); };
  const handleNetworkPointer = (event: React.PointerEvent) => {
    if (event.buttons !== 1 || !networkRef.current) return;
    setNetworkPan((pan) => ({ x: pan.x + event.movementX, y: pan.y + event.movementY }));
  };

  return <div className="site-shell">
    <div className="grain" aria-hidden="true" />
    <header className={`topbar ${progress > 0.02 ? "topbar-scrolled" : ""}`}>
      <button className="brand" onClick={() => scrollTo("hero")} aria-label="Go to top"><span className="brand-mark"><Compass size={17} /></span><span>SKILL<span className="brand-accent">LENS</span></span><sup>AI</sup></button>
      <nav className={`topnav ${menuOpen ? "topnav-open" : ""}`}>
        <button onClick={() => scrollTo("profile")}>Profile</button><button onClick={() => scrollTo("roadmap")}>Roadmap</button><button onClick={() => scrollTo("network")}>Skill network</button><button onClick={() => scrollTo("simulator")}>Simulator</button>
      </nav>
      <div className="topbar-actions">{user ? <span className="status-pulse"><i />{user.name || "Profile"} synced</span> : <button className="ghost-button auth-button" onClick={() => startLogin()}>Sign in to save</button>}<button className="ghost-button topbar-cta" onClick={() => scrollTo("simulator")}>Analyze my skills <ArrowUpRight size={15} /></button><button className="menu-button" onClick={() => setMenuOpen((open) => !open)} aria-label="Toggle navigation">{menuOpen ? <X size={18} /> : <Menu size={18} />}</button></div>
    </header>

    <div className="scroll-rail" aria-hidden="true"><span style={{ height: `${progress * 100}%` }} /></div>

    <main>
      <section id="hero" className="hero section-dark">
        <div className="hero-stage" ref={stageRef}>
          <div className="hero-orbit orbit-one" style={{ transform: `translate3d(${pointer.x * -18}px, ${pointer.y * -12}px, 0) rotate(${progress * 18}deg)` }} />
          <div className="hero-orbit orbit-two" style={{ transform: `translate3d(${pointer.x * 22}px, ${pointer.y * 16}px, 0) rotate(${progress * -12}deg)` }} />
          <div className="hero-grid" />
          <div className="hero-content">
            <div className="eyebrow"><span className="eyebrow-number">00 / 10</span><span className="eyebrow-line" /><span>Career intelligence system</span></div>
            <div className="hero-kicker"><span className="live-dot" />Live map · Alex Sharma · AI Engineer</div>
            <h1>YOUR CAREER<br /><em>HAS A MAP.</em></h1>
            <p className="hero-lede">SkillLens AI turns your resume, skills, and ambition into an actionable route to what comes next.</p>
            <div className="hero-actions"><button className="primary-button" onClick={() => scrollTo("profile")}>Analyze my skills <ArrowRight size={17} /></button><button className="text-button" onClick={() => scrollTo("profile")}>Explore demo <span>↓</span></button></div>
            <div className="hero-tags">{["Skill gap analysis", "AI career roadmap", "Future skills", "Job matching"].map((tag) => <span key={tag}>{tag}</span>)}</div>
          </div>
          <div className="hero-map-card" style={{ transform: `translate3d(${pointer.x * 28}px, ${pointer.y * 18 - profileLift}px, 0)` }}>
            <div className="map-card-top"><span>PROFILE / ALEX SHARMA</span><span className="map-live"><i />SYNCED</span></div>
            <div className="map-card-map"><div className="radar-sweep" /><div className="radar-ring ring-a" /><div className="radar-ring ring-b" /><div className="radar-line line-a" /><div className="radar-line line-b" /><span className="map-node node-a" /><span className="map-node node-b" /><span className="map-node node-c" /><div className="map-route"><span /><span /><span /></div><div className="map-card-callout"><span>01 / NOW</span><strong>72%</strong><small>job readiness</small></div></div>
            <div className="map-card-bottom"><span><Target size={13} /> Target role</span><strong>AI Engineer</strong><span className="map-coordinates">12.9716° N&nbsp;&nbsp;77.5946° E</span></div>
          </div>
          <div className="hero-bottom"><span>Scroll to navigate</span><div className="scroll-line"><i /></div><span>01 — 10</span></div>
        </div>
      </section>

      <section className="statement-section section-paper" id="intro">
        <div className="container split-statement" data-reveal id="statement-reveal">
          <SectionLabel index="01" eyebrow="The starting point">YOUR CURRENT POSITION</SectionLabel>
          <div><h2>Most people know the job they want.<br /><span>They don't know what stands between.</span></h2><p className="statement-copy">SkillLens AI reads the signal across your resume, skills, projects, experience, target role, and industry requirements — then turns uncertainty into a visual career map.</p><div className="data-points">{["Resume", "Skills", "Projects", "Experience", "Target role", "Industry signal"].map((item, index) => <span key={item} style={{ "--delay": `${index * 50}ms` } as React.CSSProperties}><CircleDot size={13} />{item}</span>)}</div></div>
        </div>
      </section>

      <section className="profile-section section-ink" id="profile">
        <div className="container section-heading" data-reveal id="profile-heading"><SectionLabel index="02" eyebrow="Scene 01">CURRENT PROFILE</SectionLabel><h2>KNOW WHERE<br /><em>YOU ARE.</em></h2><p>One living profile. Eight signals. A clearer starting line.</p></div>
        <div className="container profile-layout">
          <div className="profile-card glass-panel" data-reveal id="profile-card"><div className="profile-card-header"><div><span className="micro-label">DEMO PROFILE</span><h3>Alex Sharma</h3><p>AI Engineer · 2 years experience</p></div><div className="profile-avatar">AS</div></div><div className="score-row"><div><span className="micro-label">JOB READINESS</span><strong>72<span>%</span></strong></div><div><span className="micro-label">FUTURE SCORE</span><strong>68<span>%</span></strong></div><div className="score-spark"><LineChart size={19} /><span>+14% route lift</span></div></div><div className="profile-card-footer"><span><i className="green-dot" />Analysis complete</span><span>Updated just now</span></div></div>
          <div className="skills-panel"><div className="skills-panel-top"><div><span className="micro-label">SKILL SIGNALS</span><h3>What your profile tells us</h3></div><span className="skills-count">08 / 08</span></div><div className="skill-grid">{skills.map((skill) => <button className={`skill-chip ${selectedSkill.name === skill.name ? "skill-chip-active" : ""}`} key={skill.name} onClick={() => setSelectedSkill(skill)}><span className="skill-chip-name"><i style={{ background: skill.color }} />{skill.name}</span><strong>{skill.current}%</strong><small>{skill.status}</small></button>)}</div><div className="skill-detail"><div className="skill-detail-top"><div><span className="micro-label">SELECTED SIGNAL</span><h4>{selectedSkill.name}</h4></div><span className={`status-badge ${selectedSkill.priority.toLowerCase()}`}>{selectedSkill.priority}</span></div><ProgressBar value={selectedSkill.current} required={selectedSkill.required} color={selectedSkill.color} /><div className="skill-detail-values"><span><b>{selectedSkill.current}%</b> current</span><span><b>{selectedSkill.required}%</b> role target</span><span><b>{selectedSkill.required - selectedSkill.current > 0 ? `${selectedSkill.required - selectedSkill.current}%` : "On target"}</b> gap</span></div><p>{selectedSkill.name === "MLOps" ? "The constraint currently capping your readiness. Closing this gap unlocks higher-confidence production work." : `${selectedSkill.name} is ${selectedSkill.current >= selectedSkill.required ? "on target for" : "below the current target for"} your AI Engineer route.`}</p></div></div>
        </div>
        <div className="container intake-layout" data-reveal id="intake-panel"><div className="intake-copy"><SectionLabel index="02A" eyebrow="Bring your own signal">PROFILE INTAKE</SectionLabel><h3>UPLOAD THE<br /><em>REAL STORY.</em></h3><p>Drop in a resume, text file, PDF, DOCX, spreadsheet, presentation, or image. SkillLens will explain what your evidence means for a specific role.</p><div className="intake-supported"><FileText size={14} />PDF · DOCX · XLSX · PPTX · TXT · CSV · IMAGE</div></div><div className="intake-card glass-panel"><div className="intake-controls"><label><span className="micro-label">TARGET ROLE</span><input value={targetRole} onChange={(event) => setTargetRole(event.target.value)} placeholder="e.g. AI Engineer" /></label><input ref={documentInputRef} type="file" className="visually-hidden-input" onChange={(event) => handleDocumentUpload(event.target.files?.[0])} accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.md,.json,.csv,.xml,.rtf,image/*" /><button className="upload-dropzone" onClick={() => documentInputRef.current?.click()}><UploadCloud size={22} /><span>{uploadedFileName || "Choose a career document"}</span><small>{documentMutation.isPending ? "Analyzing evidence…" : "Max 10 MB · stored securely"}</small></button><button className="primary-button intake-button" onClick={() => documentInputRef.current?.click()} disabled={documentMutation.isPending}>{documentMutation.isPending ? "Analyzing…" : "Analyze for this role"}<ArrowRight size={16} /></button>{uploadError && <p className="upload-error">{uploadError}</p>}{!user && <p className="intake-note">You can analyze as a guest. Sign in to persist your document and career map.</p>}</div>{analysisResult && <div className="analysis-results"><div className="analysis-result-head"><div><span className="micro-label">ROLE FIT / {targetRole.toUpperCase()}</span><h4>{analysisResult.roleFitScore}% directional fit</h4></div><span className="status-badge good">AI ANALYSIS</span></div><p className="analysis-summary">{analysisResult.summary}</p><div className="analysis-grid"><div><span className="micro-label">WHAT YOU ALREADY HAVE</span>{analysisResult.strengths.slice(0, 3).map((item) => <span className="analysis-item" key={item}><Check size={13} />{item}</span>)}</div><div><span className="micro-label">WHAT TO CLOSE NEXT</span>{analysisResult.gaps.slice(0, 3).map((item) => <span className="analysis-item" key={item.skill}><Zap size={13} />{item.skill} · {item.current}% → {item.required}%</span>)}</div></div><div className="role-directions"><span className="micro-label">WHERE THIS PROFILE COULD TRAVEL</span>{analysisResult.roleDirections.slice(0, 3).map((item) => <div className="role-direction" key={`${item.role}-${item.location}`}><strong>{item.role}</strong><span>{item.location} · {item.chance}</span><small>{item.why}</small></div>)}</div><div className="analysis-next"><span className="micro-label">NEXT MOVES</span>{analysisResult.nextSteps.slice(0, 3).map((item, index) => <span key={item}><b>0{index + 1}</b>{item}</span>)}</div></div>}</div></div>
        <div className="container history-layout" data-reveal id="resume-history"><div className="history-copy"><SectionLabel index="02B" eyebrow="Version control">RESUME HISTORY</SectionLabel><h3>KEEP THE<br /><em>TRAJECTORY.</em></h3><p>Every signed-in analysis is saved. Select two versions to see which evidence is stronger for the target role and what changed.</p>{!user && <p className="intake-note">Sign in to save analysis history and compare resumes.</p>}</div><div className="history-card glass-panel"><div className="history-toolbar"><div><span className="micro-label">SAVED DOCUMENTS</span><strong>{documentHistoryQuery.data?.length ?? 0} analyses</strong></div><button className="primary-button compare-button" disabled={selectedHistoryIds.length !== 2 || compareMutation.isPending} onClick={compareSelectedDocuments}>{compareMutation.isPending ? "Comparing…" : "Compare selected"}<ArrowRight size={15} /></button></div>{user && documentHistoryQuery.data?.length ? <div className="history-list">{documentHistoryQuery.data.map((document) => <button className={`history-item ${selectedHistoryIds.includes(document.id) ? "history-item-selected" : ""}`} key={document.id} onClick={() => toggleHistoryDocument(document.id)}><span className="history-check">{selectedHistoryIds.includes(document.id) ? <Check size={13} /> : <FileText size={13} />}</span><span className="history-file"><strong>{document.fileName}</strong><small>{document.targetRole} · {new Date(document.createdAt).toLocaleDateString()}</small></span><span className="history-fit">{document.analysis?.roleFitScore ?? "—"}%<small>fit</small></span></button>)}</div> : <div className="history-empty"><FileText size={20} /><span>{user ? "Your analyzed resumes will appear here." : "Sign in to create your private resume history."}</span></div>}{comparisonResult && <div className="comparison-result"><div className="analysis-result-head"><div><span className="micro-label">RESUME COMPARISON / {targetRole.toUpperCase()}</span><h4>{comparisonResult.winner === "tie" ? "A balanced result" : `${comparisonResult.winner === "resume-a" ? comparisonResult.left.fileName : comparisonResult.right.fileName} leads`}</h4></div><span className="status-badge good">SAVED</span></div><p className="analysis-summary">{comparisonResult.summary} {comparisonResult.winnerReason}</p><div className="comparison-change-list">{comparisonResult.changes.slice(0, 4).map((change) => <div className="comparison-change" key={change.category}><strong>{change.category}</strong><span><b>A</b>{change.resumeA}</span><span><b>B</b>{change.resumeB}</span></div>)}</div><div className="analysis-next"><span className="micro-label">NEXT MOVES</span>{comparisonResult.nextSteps.slice(0, 3).map((step, index) => <span key={step}><b>0{index + 1}</b>{step}</span>)}</div></div>}</div></div>
      </section>

      <section className="gap-section section-paper" id="gap">
        <div className="container gap-layout"><div className="gap-copy" data-reveal id="gap-copy"><SectionLabel index="03" eyebrow="Scene 02">ROLE COMPARISON</SectionLabel><h2>SEE<br /><em>THE GAP.</em></h2><blockquote>“Your resume tells you what you've done.<br /><strong>SkillLens tells you what you're missing.</strong>”</blockquote><div className="gap-callout"><span className="micro-label">BIGGEST GAP</span><strong>MLOps</strong><div><span>18%</span><ArrowRight size={17} /><span>70%</span></div><small>52 point gap · critical for production AI roles</small></div></div><div className="comparison-card" data-reveal id="comparison-card"><div className="comparison-head"><span>SKILL</span><span>CURRENT</span><span>REQUIRED</span></div>{skills.slice(0, 6).reverse().map((skill, index) => <button className={`comparison-row ${skill.name === "MLOps" ? "comparison-critical" : ""}`} key={skill.name} onClick={() => setSelectedSkill(skill)}><span><i style={{ background: skill.color }} />{skill.name}</span><span className="bar-cell"><small>{skill.current}%</small><span className="mini-track"><i style={{ width: `${skill.current}%`, background: skill.color }} /></span></span><span className="bar-cell"><small>{skill.required}%</small><span className="mini-track"><i className="required-bar" style={{ width: `${skill.required}%` }} /></span></span></button>)}<div className="comparison-note"><Zap size={14} /> Role requirements are estimated from the target profile, not a hiring guarantee.</div></div></div>
      </section>

      <section className="priority-section section-dark" id="priorities">
        <div className="container priority-layout"><div className="priority-intro" data-reveal id="priority-intro"><SectionLabel index="04" eyebrow="Scene 03">THE ORDER MATTERS</SectionLabel><h2>NOT EVERY<br /><em>GAP</em> MATTERS<br />EQUALLY.</h2><p>SkillLens ranks gaps by role importance, proficiency distance, industry relevance, learning effort, dependencies, and future relevance.</p><button className="outline-button" onClick={() => scrollTo("roadmap")}>See the route <ArrowRight size={16} /></button></div><div className="priority-stack" data-reveal id="priority-stack">{["MLOps", "LLMs & RAG", "Cloud", "Docker", "Machine Learning"].map((item, index) => <button className={`priority-item ${index === 0 ? "priority-top" : ""}`} key={item} onClick={() => setSelectedSkill(skills.find((skill) => skill.name === item) ?? skills[0])}><span className="priority-number">0{index + 1}</span><span><strong>{item}</strong><small>{index === 0 ? "CRITICAL" : index === 1 ? "HIGH" : "HIGH"}</small></span><ChevronRight size={18} /></button>)}</div></div>
      </section>

      <section className="roadmap-section section-ink" id="roadmap">
        <div className="container section-heading roadmap-heading" data-reveal id="roadmap-heading"><SectionLabel index="05" eyebrow="Scene 04">THE PERSONAL ROUTE</SectionLabel><h2>TURN GAPS INTO<br /><em>A ROADMAP.</em></h2><p>Don't just tell users what they're missing. Tell them what to do next.</p></div>
        <div className="container roadmap-list">{roadmap.map((item) => { const done = completedRoadmap.includes(item.id); return <div className={`roadmap-row ${openRoadmap === item.id ? "roadmap-open" : ""} ${done ? "roadmap-done" : ""}`} key={item.id}><button className="roadmap-toggle" onClick={() => setOpenRoadmap(openRoadmap === item.id ? null : item.id)}><span className="roadmap-index">{item.id}</span><span className="roadmap-title"><strong>{item.title}</strong><small>{item.skills.join(" · ")}</small></span><span className="roadmap-meta">{item.duration}<br /><small>{item.difficulty}</small></span><ChevronDown size={18} /></button>{openRoadmap === item.id && <div className="roadmap-detail"><div className="roadmap-skills">{item.skills.map((skill) => <span key={skill}><CircleDot size={12} />{skill}</span>)}</div><div className="roadmap-detail-side"><span className="micro-label">RECOMMENDED PROJECT</span><strong>{item.project}</strong><button className={`complete-button ${done ? "is-complete" : ""}`} onClick={() => toggleRoadmapComplete(item.id)}>{done ? <><Check size={14} />Completed</> : <><CircleCheck size={14} />Mark phase complete</>}</button></div></div>}</div>; })}</div>
      </section>

      <section className="intelligence-section section-paper" id="intelligence">
        <div className="container intelligence-top" data-reveal id="intelligence-top"><SectionLabel index="06" eyebrow="Scene 05">THE TOOLKIT</SectionLabel><div><h2>SKILL<br /><em>INTELLIGENCE.</em></h2><p>Every signal becomes a move you can make.</p></div></div>
        <div className="container intelligence-carousel"><div className="carousel-progress"><span style={{ width: `${((activeCard + 1) / intelligenceCards.length) * 100}%` }} /></div><div className="carousel-window"><div className="carousel-track" style={{ transform: `translateX(calc(-${activeCard} * (min(82vw, 360px) + 16px)))` }}>{intelligenceCards.map((card, index) => { const Icon = card.icon; return <button className={`intel-card ${activeCard === index ? "intel-card-active" : ""}`} key={card.id} onClick={() => setActiveCard(index)}><div className="intel-card-top"><span>{card.id}</span><Icon size={19} /></div><h3>{card.title}</h3><p>{card.copy}</p><span className="intel-meta">{card.meta}<ArrowUpRight size={14} /></span></button>; })}</div></div><div className="carousel-controls"><span>0{activeCard + 1} <i /> 0{intelligenceCards.length}</span><div><button onClick={() => setActiveCard((activeCard - 1 + intelligenceCards.length) % intelligenceCards.length)} aria-label="Previous card"><ArrowRight size={16} className="rotate-180" /></button><button onClick={() => setActiveCard((activeCard + 1) % intelligenceCards.length)} aria-label="Next card"><ArrowRight size={16} /></button></div></div></div>
      </section>

      <section className="network-section section-dark" id="network">
        <div className="container network-header" data-reveal id="network-header"><SectionLabel index="07" eyebrow="Scene 06">THE SKILL NETWORK</SectionLabel><div><h2>YOUR SKILLS<br /><em>ARE CONNECTED.</em></h2><p>Pan, zoom, and select a node. Your next move lives in the relationships between skills.</p></div></div>
        <div className="container network-layout"><div className="network-canvas glass-panel" ref={networkRef} onWheel={handleNetworkWheel} onPointerMove={handleNetworkPointer} onDoubleClick={() => { setNetworkZoom(1); setNetworkPan({ x: 0, y: 0 }); }}><div className="network-toolbar"><span><Network size={15} /> Interactive network</span><div><button onClick={() => setNetworkZoom((zoom) => clamp(zoom - 0.1, 0.75, 1.8))}><Minus size={14} /></button><span>{Math.round(networkZoom * 100)}%</span><button onClick={() => setNetworkZoom((zoom) => clamp(zoom + 0.1, 0.75, 1.8))}><Plus size={14} /></button></div></div><div className="network-viewport" style={{ transform: `translate(${networkPan.x}px, ${networkPan.y}px) scale(${networkZoom})` }}>{[["python", "ml"], ["ml", "rag"], ["python", "fastapi"], ["fastapi", "docker"], ["docker", "mlops"], ["mlops", "cloud"], ["python", "sql"], ["rag", "cloud"]].map(([from, to]) => { const a = networkNodes.find((node) => node.id === from)!; const b = networkNodes.find((node) => node.id === to)!; return <svg className="network-edge" key={`${from}-${to}`}><line x1={`${a.x}%`} y1={`${a.y}%`} x2={`${b.x}%`} y2={`${b.y}%`} /></svg>; })}{networkNodes.map((node) => <button key={node.id} className={`network-node node-${node.tone} ${selectedNode.id === node.id ? "node-selected" : ""}`} style={{ left: `${node.x}%`, top: `${node.y}%` }} onClick={() => setSelectedNode(node)}><span className="node-pulse" /><strong>{node.label}</strong><small>{node.value}</small></button>)}</div><div className="network-hint"><span>Scroll to zoom · drag to pan · double click to reset</span><span>{networkNodes.length} nodes · 8 connections</span></div></div><aside className="node-detail"><span className="micro-label">SELECTED NODE</span><div className="node-detail-title"><span className={`detail-dot node-${selectedNode.tone}`} /><h3>{selectedNode.label}</h3></div><strong className="node-detail-score">{selectedNode.value}</strong><p>{selectedNode.detail}</p><div className="node-detail-path"><span>Connected to</span><div>{networkNodes.filter((node) => node.id !== selectedNode.id).slice(0, 3).map((node) => <button key={node.id} onClick={() => setSelectedNode(node)}>{node.label}<ChevronRight size={13} /></button>)}</div></div><button className="outline-button full-button" onClick={() => scrollTo("simulator")}>Simulate this path <ArrowRight size={16} /></button></aside></div>
      </section>

      <section className="projects-section section-paper" id="projects">
        <div className="container projects-header" data-reveal id="projects-header"><SectionLabel index="08" eyebrow="Scene 07">PROOF OF WORK</SectionLabel><div><h2>BUILD WHAT<br /><em>YOUR PROFILE NEEDS.</em></h2><p>Projects are not filler. They are the shortest path from a gap to credible evidence.</p></div></div><div className="container projects-grid">{projects.map((project) => { const added = addedProjects.includes(project.id); const open = selectedProject === project.id; return <article className={`project-card ${open ? "project-open" : ""}`} key={project.id}><div className="project-card-top"><span>PROJECT / {project.id}</span><span className={`difficulty ${project.difficulty.toLowerCase()}`}>{project.difficulty}</span></div><h3>{project.title}</h3><p>{open ? project.description : "A tailored build designed around your highest-leverage gaps."}</p><div className="tag-row">{project.tags.map((tag) => <span key={tag}>{tag}</span>)}</div><div className="project-card-footer"><span><Terminal size={14} />{project.time}</span><button className={added ? "added" : ""} onClick={() => toggleProject(project.id)}>{added ? <><Check size={14} />Added</> : <><Plus size={14} />Add to roadmap</>}</button></div><button className="project-details" onClick={() => setSelectedProject(open ? null : project.id)}>{open ? "Hide details" : "View project details"}<ChevronRight size={14} /></button></article>; })}</div>
      </section>

      <section className="future-section section-dark" id="future">
        <div className="future-glow" /><div className="container future-layout"><div className="future-copy" data-reveal id="future-copy"><SectionLabel index="09" eyebrow="Scene 08">THE SIGNAL AHEAD</SectionLabel><h2>DON'T PREPARE<br />FOR TODAY'S JOB.<br /><em>PREPARE FOR<br />TOMORROW'S.</em></h2><p>Future relevance is a dimension of readiness. SkillLens surfaces the compounding skills before they are table stakes.</p><div className="future-sequence"><span>Current proficiency</span><ArrowDownRight size={16} /><span>Future relevance</span><ArrowDownRight size={16} /><span>Learning priority</span></div></div><div className="future-orbit-wrap" data-reveal id="future-orbit"><div className="future-orbit"><div className="future-core"><Sparkles size={20} /><strong>AI</strong><small>signal map</small></div>{futureSkills.map((skill, index) => <button className="future-node" key={skill} style={{ "--angle": `${index * 45}deg`, "--radius": `${112 + (index % 2) * 28}px` } as React.CSSProperties}>{skill}</button>)}</div></div></div>
      </section>

      <section className="jobs-section section-paper" id="jobs">
        <div className="container jobs-layout"><div className="jobs-copy" data-reveal id="jobs-copy"><SectionLabel index="10" eyebrow="Scene 09">LIVE OPPORTUNITY RADAR</SectionLabel><h2>WHERE CAN<br /><em>YOUR SKILLS</em><br />TAKE YOU?</h2><p>Live listings are ranked against your target role and current gaps. Open the original posting to review requirements and apply.</p><div className="job-filter"><Search size={15} /><span>{jobSearchRole} · Remote</span><span className="live-job-status"><i />{liveJobsQuery.isFetching ? "refreshing" : "live"}</span></div><div className="job-source-note">Sources: {liveJobsQuery.data?.sources.filter((source) => source.ok).map((source) => <a href={source.url} target="_blank" rel="noreferrer" key={source.name}>{source.name}</a>) ?? <span>Himalayas · Arbeitnow</span>}</div></div><div className="job-list" data-reveal id="job-list">{liveJobsQuery.isPending && <div className="history-empty"><Search size={18} />Finding current openings…</div>}{liveJobs.length ? liveJobs.map((job, index) => <a className={`job-card ${selectedLiveJobIndex === index ? "job-selected" : ""}`} key={job.id} href={job.applyUrl} target="_blank" rel="noreferrer" onClick={() => setSelectedLiveJobIndex(index)}><div className="job-match"><strong>{job.match}%</strong><span>fit</span></div><div className="job-main"><span className="micro-label">{job.company} · {job.location}</span><h3>{job.title}</h3><div className="job-tags"><span>{job.summary}</span><span className="missing">{job.source} · live listing</span></div></div><ExternalLink size={17} /></a>) : jobs.map((job) => <button className={`job-card ${selectedJob.role === job.role ? "job-selected" : ""}`} key={job.role} onClick={() => setSelectedJob(job)}><div className="job-match"><strong>{job.match}%</strong><span>match</span></div><div className="job-main"><span className="micro-label">{job.company} · {job.place}</span><h3>{job.role}</h3><div className="job-tags"><span>Matched: {job.matched.slice(0, 2).join(" · ")}</span><span className="missing">Missing: {job.missing.join(" · ")}</span></div></div><ChevronRight size={18} /></button>)}{liveJobsQuery.isError && <div className="job-source-note">Live sources are temporarily unavailable; showing the demo matches. Try refresh again shortly.</div>}{activeLiveJob ? <div className="job-detail-inline"><div><span className="micro-label">SELECTED LIVE MATCH</span><h3>{activeLiveJob.title}</h3><p>{activeLiveJob.summary}</p><a href={activeLiveJob.applyUrl} target="_blank" rel="noreferrer">View original posting <ExternalLink size={13} /></a></div><div className="job-detail-cols"><div><span>Company</span><b>{activeLiveJob.company}</b></div><div><span>Source</span><b>{activeLiveJob.source}</b></div></div></div> : <div className="job-detail-inline"><div><span className="micro-label">SELECTED MATCH</span><h3>{selectedJob.role}</h3></div><div className="job-detail-cols"><div><span>Matched</span>{selectedJob.matched.map((skill) => <b key={skill}><Check size={13} />{skill}</b>)}</div><div><span>Missing</span>{selectedJob.missing.map((skill) => <b key={skill}><Plus size={13} />{skill}</b>)}</div></div></div>}<div className="job-source-note">Listings are provided by the original job boards and may be delayed or expire. SkillLens fit is directional, not a hiring guarantee.</div></div></div>
      </section>

      <section className="radar-section section-ink" id="radar"><div className="container radar-layout"><div className="radar-copy" data-reveal id="radar-copy"><SectionLabel index="11" eyebrow="Scene 10">GLOBAL CAREER RADAR</SectionLabel><h2>THE WORLD IS<br /><em>YOUR CAREER MAP.</em></h2><p>Demand is not evenly distributed. See where your target skills are being pulled next.</p><div className="radar-legend"><span><i className="demand-high" />Very high</span><span><i className="demand-mid" />High</span><span><i className="demand-low" />Growing</span></div></div><div className="globe-visual" style={{ transform: `translate3d(${pointer.x * 16}px, ${pointer.y * 12}px, 0) rotateY(${pointer.x * 5}deg)` }} data-reveal id="globe-visual"><div className="globe"><div className="globe-lat lat-one" /><div className="globe-lat lat-two" /><div className="globe-lat lat-three" /><div className="globe-long long-one" /><div className="globe-long long-two" /><div className="globe-long long-three" /><span className="globe-dot india" /><span className="globe-dot usa" /><span className="globe-dot germany" /><span className="globe-dot singapore" /><span className="globe-dot canada" /></div><div className="globe-label label-india"><strong>INDIA</strong><span>AI demand · very high</span></div><div className="globe-label label-usa"><strong>USA</strong><span>AI demand · high</span></div><div className="globe-label label-germany"><strong>GERMANY</strong><span>AI demand · high</span></div></div></div></section>

      <section className="simulator-section section-dark" id="simulator"><div className="container simulator-layout"><div className="simulator-copy" data-reveal id="simulator-copy"><SectionLabel index="12" eyebrow="Scene 11">THE WHAT-IF ENGINE</SectionLabel><h2>WHAT IF YOU<br />LEARNED<br /><em>ONE MORE<br />SKILL?</em></h2><p>See how your career profile could change before you spend months learning.</p><span className="estimate-note"><Sparkles size={14} />AI simulation / estimate · not a guaranteed employment probability</span></div><div className="simulator-card glass-panel" data-reveal id="simulator-card"><div className="simulator-score"><span className="micro-label">SIMULATED READINESS</span><div><strong>{simulatedScore}%</strong><span className="score-delta">{simSkills.length ? `+${simulatedScore - 72}%` : "Current"}</span></div><div className="sim-score-track"><i style={{ width: `${simulatedScore}%` }} /></div></div><div className="sim-options"><span className="micro-label">ADD A SKILL TO THE MAP</span><div>{["MLOps", "AWS", "Docker", "RAG", "LLMs", "Kubernetes", "CI/CD"].map((skill) => <button className={simSkills.includes(skill) ? "sim-active" : ""} key={skill} onClick={() => toggleSimSkill(skill)}>{simSkills.includes(skill) ? <Check size={14} /> : <Plus size={14} />}{skill}</button>)}</div></div><div className="sim-outcomes"><span><i />Skill gap reduced</span><span><i />Job matches +{simSkills.length ? Math.min(12, simSkills.length * 3) : 0}</span><span><i />Future readiness +{simSkills.length ? Math.min(10, simSkills.length * 2) : 0}</span></div><div className="sim-footnote">Simulation uses the Alex Sharma demo profile and role-weighted estimates.</div></div></div></section>

      <section className="final-section section-paper" id="final"><div className="container final-layout"><div className="final-steps" data-reveal id="final-steps">{["Know where you are.", "Know what's missing.", "Know what to learn next.", "Know where you can go."].map((step, index) => <div key={step} className={index === 3 ? "final-step final-step-active" : "final-step"}><span>0{index + 1}</span><strong>{step}</strong></div>)}</div><div className="final-cta" data-reveal id="final-cta"><div className="final-orbit-mark"><Compass size={32} /></div><span className="micro-label">THE CAREER GPS</span><h2>SKILL<span>LENS</span> AI</h2><p>Your AI-powered career skill GPS.</p><div className="final-actions"><button className="primary-button" onClick={() => scrollTo("simulator")}>Start your career analysis <ArrowUpRight size={17} /></button><button className="text-button" onClick={() => scrollTo("profile")}>Explore Alex Sharma demo <ArrowRight size={15} /></button></div></div></div><div className="container footer-line"><span>© 2026 SkillLens AI</span><span>Career intelligence, made navigable.</span><button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>Back to top ↑</button></div></section>
    </main>

    <button className={`assistant-trigger ${assistantOpen ? "assistant-trigger-open" : ""}`} onClick={() => setAssistantOpen((open) => !open)} aria-label="Open AI career assistant">{assistantOpen ? <X size={20} /> : <MessageCircle size={20} />}<span>AI coach</span></button>
    {assistantOpen && <div className="assistant-panel glass-panel"><div className="assistant-header"><div><span className="micro-label">SKILLLENS ASSISTANT</span><strong>Ask about your route</strong></div><span className="assistant-online"><i />{assistantMutation.isPending ? "thinking" : "online"}</span></div><div className="assistant-body"><div className="assistant-message"><Bot size={15} /><p>Ask me anything about your career route.</p></div><div className="assistant-prompts">{Object.keys(coachAnswers).map((question) => <button key={question} onClick={() => submitAssistantQuestion(question)}>{question}</button>)}</div><div className="assistant-answer"><span>{assistantQuestion}</span><p>{assistantMutation.isPending ? "Mapping your question to the profile…" : assistantAnswer}</p></div></div><div className="assistant-input"><input value={assistantQuestion} onChange={(event) => setAssistantQuestion(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") submitAssistantQuestion(assistantQuestion); }} aria-label="Ask a question" placeholder="Ask your own question…" /><button onClick={() => submitAssistantQuestion(assistantQuestion)} aria-label="Send question"><ArrowRight size={16} /></button></div></div>}
    <div className="scene-indicator"><span>SCENE</span><strong>{String(Math.min(currentScene + 1, 12)).padStart(2, "0")}</strong><span>/ 12</span></div>
  </div>;
}
