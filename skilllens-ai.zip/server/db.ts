import { and, desc, eq, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { careerDocuments, careerProfiles, InsertUser, resumeComparisons, roadmapProgress, savedProjects, simulatorSessions, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getCareerSnapshot(userId: number) {
  const db = await getDb();
  if (!db) return { profile: undefined, roadmap: [], projects: [], simulations: [] };

  const [profile, roadmap, projects, simulations] = await Promise.all([
    db.select().from(careerProfiles).where(eq(careerProfiles.userId, userId)).limit(1),
    db.select().from(roadmapProgress).where(eq(roadmapProgress.userId, userId)),
    db.select().from(savedProjects).where(eq(savedProjects.userId, userId)),
    db.select().from(simulatorSessions).where(eq(simulatorSessions.userId, userId)).orderBy(desc(simulatorSessions.createdAt)).limit(10),
  ]);

  return { profile: profile[0], roadmap, projects, simulations };
}

export async function saveCareerProfile(input: {
  userId: number;
  name: string;
  targetRole: string;
  experience: string;
  readinessScore: number;
  futureScore: number;
  skillsJson: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(careerProfiles).values(input).onDuplicateKeyUpdate({
    set: {
      name: input.name,
      targetRole: input.targetRole,
      experience: input.experience,
      readinessScore: input.readinessScore,
      futureScore: input.futureScore,
      skillsJson: input.skillsJson,
    },
  });
  const result = await db.select().from(careerProfiles).where(eq(careerProfiles.userId, input.userId)).limit(1);
  return result[0];
}

export async function saveRoadmapProgress(userId: number, phaseId: string, completed: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(roadmapProgress).values({ userId, phaseId, completed: completed ? 1 : 0 }).onDuplicateKeyUpdate({
    set: { completed: completed ? 1 : 0 },
  });
}

export async function saveProjectProgress(userId: number, projectId: string, completed: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(savedProjects).values({ userId, projectId, completed: completed ? 1 : 0 }).onDuplicateKeyUpdate({
    set: { completed: completed ? 1 : 0 },
  });
}

export async function saveSimulatorSession(userId: number, selectedSkillsJson: string, simulatedScore: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(simulatorSessions).values({ userId, selectedSkillsJson, simulatedScore });
}

export async function saveCareerDocument(input: {
  userId?: number;
  fileName: string;
  mimeType: string;
  storageKey: string;
  targetRole: string;
  extractedText?: string;
  analysisJson: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(careerDocuments).values(input);
  return { id: Number(result[0].insertId) };
}

export async function getCareerDocumentHistory(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(careerDocuments).where(eq(careerDocuments.userId, userId)).orderBy(desc(careerDocuments.createdAt)).limit(30);
}

export async function getCareerDocumentsByIds(userId: number, ids: number[]) {
  const db = await getDb();
  if (!db || ids.length === 0) return [];
  return db.select().from(careerDocuments).where(and(eq(careerDocuments.userId, userId), inArray(careerDocuments.id, ids)));
}

export async function saveResumeComparison(input: {
  userId: number;
  leftDocumentId: number;
  rightDocumentId: number;
  targetRole: string;
  resultJson: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(resumeComparisons).values(input);
  return { id: Number(result[0].insertId) };
}
