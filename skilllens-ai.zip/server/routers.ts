import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { invokeLLM } from "./_core/llm";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { getCareerDocumentsByIds, getCareerDocumentHistory, getCareerSnapshot, saveCareerDocument, saveCareerProfile, saveProjectProgress, saveResumeComparison, saveRoadmapProgress, saveSimulatorSession } from "./db";
import { storageGetSignedUrl, storagePut } from "./storage";
import JSZip from "jszip";
import mammoth from "mammoth";
import * as XLSX from "xlsx";

async function extractCareerDocumentText(buffer: Buffer, fileName: string, mimeType: string) {
  if (mimeType.startsWith("text/") || ["application/json", "application/xml", "text/csv", "application/rtf"].includes(mimeType) || /\.(txt|md|json|csv|xml|html|rtf)$/i.test(fileName)) {
    return buffer.toString("utf8").slice(0, 24_000);
  }
  if (mimeType.includes("wordprocessingml") || /\.docx$/i.test(fileName)) {
    return (await mammoth.extractRawText({ buffer })).value.slice(0, 24_000);
  }
  if (mimeType.includes("spreadsheet") || mimeType.includes("excel") || /\.(xlsx|xls)$/i.test(fileName)) {
    const workbook = XLSX.read(buffer, { type: "buffer" });
    return workbook.SheetNames.map((sheetName) => `Sheet: ${sheetName}\n${XLSX.utils.sheet_to_csv(workbook.Sheets[sheetName])}`).join("\n\n").slice(0, 24_000);
  }
  if (mimeType.includes("presentation") || /\.(pptx)$/i.test(fileName)) {
    const zip = await JSZip.loadAsync(buffer);
    const slideNames = Object.keys(zip.files).filter((name) => /^ppt\/slides\/slide\d+\.xml$/i.test(name)).sort();
    const slides = await Promise.all(slideNames.map(async (name) => {
      const xml = await zip.files[name].async("text");
      const text = Array.from(xml.matchAll(/<a:t>(.*?)<\/a:t>/g)).map((match) => match[1]).join(" ");
      return `${name}: ${text}`;
    }));
    return slides.join("\n").slice(0, 24_000);
  }
  return undefined;
}

export function stripHtml(value: unknown) {
  return String(value ?? "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
}

export function jobRelevance(title: string, description: string, targetRole: string, skills: string[]) {
  const haystack = `${title} ${description}`.toLowerCase();
  const terms = Array.from(new Set([targetRole, ...skills].flatMap((value) => value.toLowerCase().split(/[^a-z0-9+#.]+/).filter((part) => part.length > 2))));
  const hits = terms.filter((term) => haystack.includes(term)).length;
  return Math.min(99, 50 + Math.round((hits / Math.max(terms.length, 1)) * 42));
}

async function fetchLiveJobMatches(input: { targetRole: string; skills: string[]; location?: string }) {
  const query = [input.targetRole, ...input.skills.slice(0, 5), input.location].filter(Boolean).join(" ");
  const encodedQuery = encodeURIComponent(query);
  const headers = { Accept: "application/json", "User-Agent": "SkillLensAI/1.0" };
  const responses = await Promise.allSettled([
    fetch(`https://himalayas.app/jobs/api/search?q=${encodedQuery}&sort=relevant&page=1`, { headers, signal: AbortSignal.timeout(10000) }),
    fetch(`https://www.arbeitnow.com/api/job-board-api?search=${encodedQuery}`, { headers, signal: AbortSignal.timeout(10000) }),
  ]);
  const jobs: Array<{ id: string; title: string; company: string; location: string; match: number; summary: string; applyUrl: string; source: string; sourceUrl: string; publishedAt?: string; remote: boolean; }> = [];
  const sources: Array<{ name: string; url: string; ok: boolean }> = [];

  const himalaysResponse = responses[0].status === "fulfilled" ? responses[0].value : undefined;
  if (himalaysResponse?.ok) {
    const body = await himalaysResponse.json() as { jobs?: Array<Record<string, unknown>> };
    sources.push({ name: "Himalayas", url: "https://himalayas.app/jobs", ok: true });
    for (const job of body.jobs ?? []) {
      const title = String(job.title ?? "Open role");
      const summary = stripHtml(job.excerpt ?? job.description).slice(0, 240);
      jobs.push({ id: `himalayas-${String(job.guid ?? job.companySlug ?? title)}`, title, company: String(job.companyName ?? "Hiring company"), location: Array.isArray(job.locationRestrictions) && job.locationRestrictions.length ? job.locationRestrictions.join(", ") : "Remote / worldwide", match: jobRelevance(title, summary, input.targetRole, input.skills), summary, applyUrl: String(job.applicationLink ?? "https://himalayas.app/jobs"), source: "Himalayas", sourceUrl: "https://himalayas.app/jobs", publishedAt: job.pubDate ? String(job.pubDate) : undefined, remote: true });
    }
  } else sources.push({ name: "Himalayas", url: "https://himalayas.app/jobs", ok: false });

  const arbeitnowResponse = responses[1].status === "fulfilled" ? responses[1].value : undefined;
  if (arbeitnowResponse?.ok) {
    const body = await arbeitnowResponse.json() as { data?: Array<Record<string, unknown>> };
    sources.push({ name: "Arbeitnow", url: "https://www.arbeitnow.com", ok: true });
    for (const job of body.data ?? []) {
      const title = String(job.title ?? "Open role");
      const summary = stripHtml(job.description).slice(0, 240);
      const location = String(job.location ?? (job.remote ? "Remote" : "Location not specified"));
      jobs.push({ id: `arbeitnow-${String(job.slug ?? title)}`, title, company: String(job.company_name ?? "Hiring company"), location, match: jobRelevance(title, summary, input.targetRole, input.skills), summary, applyUrl: String(job.url ?? "https://www.arbeitnow.com"), source: "Arbeitnow", sourceUrl: "https://www.arbeitnow.com", publishedAt: job.created_at ? String(job.created_at) : undefined, remote: Boolean(job.remote) });
    }
  } else sources.push({ name: "Arbeitnow", url: "https://www.arbeitnow.com", ok: false });

  if (!jobs.length) throw new Error("Live job sources are temporarily unavailable. Please try again in a minute.");
  const uniqueJobs = Array.from(new Map(jobs.map((job) => [job.id, job])).values()).sort((a, b) => b.match - a.match).slice(0, 12);
  return { jobs: uniqueJobs, sources, refreshedAt: new Date().toISOString(), query };
}

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  career: router({
    snapshot: protectedProcedure.query(({ ctx }) => getCareerSnapshot(ctx.user.id)),
    documents: protectedProcedure.query(async ({ ctx }) => {
      const documents = await getCareerDocumentHistory(ctx.user.id);
      return documents.map(({ analysisJson, extractedText: _extractedText, storageKey: _storageKey, ...document }) => ({
        ...document,
        analysis: JSON.parse(analysisJson),
      }));
    }),
    compareDocuments: protectedProcedure
      .input(z.object({ leftDocumentId: z.number().int().positive(), rightDocumentId: z.number().int().positive(), targetRole: z.string().min(1).max(160) }).refine((value) => value.leftDocumentId !== value.rightDocumentId, "Choose two different documents"))
      .mutation(async ({ ctx, input }) => {
        const documents = await getCareerDocumentsByIds(ctx.user.id, [input.leftDocumentId, input.rightDocumentId]);
        if (documents.length !== 2) throw new Error("Both resumes must belong to the signed-in user.");
        const left = documents.find((document) => document.id === input.leftDocumentId)!;
        const right = documents.find((document) => document.id === input.rightDocumentId)!;
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "You are SkillLens AI, comparing two versions of the same person's career evidence for a target role. Use only the supplied evidence. Explain which resume is stronger for the target role, where evidence changed, and what to improve next. Do not invent experience or promise employment. Return only valid JSON matching the schema." },
            { role: "user", content: `Target role: ${input.targetRole}\n\nResume A (${left.fileName}):\n${left.analysisJson}\n\nResume B (${right.fileName}):\n${right.analysisJson}` },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "resume_comparison",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  summary: { type: "string" },
                  winner: { type: "string", enum: ["resume-a", "resume-b", "tie"] },
                  winnerReason: { type: "string" },
                  changes: { type: "array", items: { type: "object", properties: { category: { type: "string" }, resumeA: { type: "string" }, resumeB: { type: "string" }, advantage: { type: "string", enum: ["resume-a", "resume-b", "tie"] } }, required: ["category", "resumeA", "resumeB", "advantage"], additionalProperties: false } },
                  nextSteps: { type: "array", items: { type: "string" } },
                },
                required: ["summary", "winner", "winnerReason", "changes", "nextSteps"],
                additionalProperties: false,
              },
            },
          },
        });
        const raw = response.choices?.[0]?.message?.content;
        const comparison = JSON.parse(typeof raw === "string" ? raw : "{}");
        const saved = await saveResumeComparison({ userId: ctx.user.id, leftDocumentId: left.id, rightDocumentId: right.id, targetRole: input.targetRole, resultJson: JSON.stringify(comparison) });
        return { ...comparison, comparisonId: saved.id, left: { id: left.id, fileName: left.fileName }, right: { id: right.id, fileName: right.fileName } };
      }),
    liveJobs: publicProcedure
      .input(z.object({ targetRole: z.string().min(1).max(160), skills: z.array(z.string()).max(20).default([]), location: z.string().max(120).optional() }))
      .query(({ input }) => fetchLiveJobMatches(input)),
    saveProfile: protectedProcedure
      .input(z.object({
        name: z.string().min(1).max(160),
        targetRole: z.string().min(1).max(160),
        experience: z.string().min(1).max(80),
        readinessScore: z.number().int().min(0).max(100),
        futureScore: z.number().int().min(0).max(100),
        skills: z.array(z.object({ name: z.string(), proficiency: z.number().int().min(0).max(100) })),
      }))
      .mutation(({ ctx, input }) => saveCareerProfile({ ...input, userId: ctx.user.id, skillsJson: JSON.stringify(input.skills) })),
    setRoadmapProgress: protectedProcedure
      .input(z.object({ phaseId: z.string().min(1).max(16), completed: z.boolean() }))
      .mutation(({ ctx, input }) => saveRoadmapProgress(ctx.user.id, input.phaseId, input.completed).then(() => ({ success: true as const }))),
    setProjectProgress: protectedProcedure
      .input(z.object({ projectId: z.string().min(1).max(16), completed: z.boolean() }))
      .mutation(({ ctx, input }) => saveProjectProgress(ctx.user.id, input.projectId, input.completed).then(() => ({ success: true as const }))),
    saveSimulator: protectedProcedure
      .input(z.object({ selectedSkills: z.array(z.string()), simulatedScore: z.number().int().min(0).max(100) }))
      .mutation(({ ctx, input }) => saveSimulatorSession(ctx.user.id, JSON.stringify(input.selectedSkills), input.simulatedScore).then(() => ({ success: true as const }))),
    analyzeDocument: publicProcedure
      .input(z.object({
        fileName: z.string().min(1).max(255),
        mimeType: z.string().min(1).max(160),
        fileBase64: z.string().min(1).max(16_000_000),
        targetRole: z.string().min(1).max(160),
      }))
      .mutation(async ({ ctx, input }) => {
        const fileBuffer = Buffer.from(input.fileBase64, "base64");
        if (fileBuffer.length > 10 * 1024 * 1024) throw new Error("Please upload a file smaller than 10 MB.");
        const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
        const upload = await storagePut(`career-documents/${ctx.user?.id ?? "guest"}/${safeName}`, fileBuffer, input.mimeType);
        const signedUrl = await storageGetSignedUrl(upload.key);
        const extractedText = await extractCareerDocumentText(fileBuffer, input.fileName, input.mimeType);
        let promptText = `Analyze this career document for the target role: ${input.targetRole}. Return the structured career analysis requested in the system message.${extractedText ? `\n\nDocument text:\n${extractedText}` : ""}`;
        const content: Array<{ type: "text"; text: string } | { type: "image_url"; image_url: { url: string; detail?: "auto" | "low" | "high" } } | { type: "file_url"; file_url: { url: string; mime_type?: "application/pdf" } }> = [{ type: "text", text: promptText }];
        if (input.mimeType.startsWith("image/")) content.push({ type: "image_url", image_url: { url: signedUrl, detail: "high" } });
        else if (input.mimeType === "application/pdf") content.push({ type: "file_url", file_url: { url: signedUrl, mime_type: "application/pdf" } });
        else if (!extractedText) {
          promptText += "\n\nThe original file is stored, but its binary format is not directly readable by the analysis model. Give a useful next-step response based on the filename and target role, and clearly explain that the user should upload a PDF or text export for a full document-grounded analysis.";
          content[0] = { type: "text", text: promptText };
        }

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "You are SkillLens AI, an evidence-led career intelligence analyst. Analyze the uploaded resume or career document against the target role. Be specific about what the person has, what is missing, how each gap affects the role, and which jobs/locations are realistic directions. Do not promise employment. Return only valid JSON matching the schema.",
            },
            { role: "user", content },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "career_analysis",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  summary: { type: "string" },
                  roleFitScore: { type: "integer", minimum: 0, maximum: 100 },
                  strengths: { type: "array", items: { type: "string" } },
                  gaps: { type: "array", items: { type: "object", properties: { skill: { type: "string" }, current: { type: "integer" }, required: { type: "integer" }, whyItMatters: { type: "string" } }, required: ["skill", "current", "required", "whyItMatters"], additionalProperties: false } },
                  nextSteps: { type: "array", items: { type: "string" } },
                  roleDirections: { type: "array", items: { type: "object", properties: { role: { type: "string" }, location: { type: "string" }, chance: { type: "string" }, why: { type: "string" } }, required: ["role", "location", "chance", "why"], additionalProperties: false } },
                },
                required: ["summary", "roleFitScore", "strengths", "gaps", "nextSteps", "roleDirections"],
                additionalProperties: false,
              },
            },
          },
        });
        const raw = response.choices?.[0]?.message?.content;
        const analysis = JSON.parse(typeof raw === "string" ? raw : "{}");
        const savedDocument = ctx.user ? await saveCareerDocument({ userId: ctx.user.id, fileName: input.fileName, mimeType: input.mimeType, storageKey: upload.key, targetRole: input.targetRole, extractedText, analysisJson: JSON.stringify(analysis) }) : undefined;
        return { analysis, documentId: savedDocument?.id, fileName: input.fileName, targetRole: input.targetRole, storedUrl: upload.url };
      }),
  }),
  assistant: router({
    ask: publicProcedure
      .input(z.object({ question: z.string().min(1).max(1200), profileContext: z.string().max(4000).optional() }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "You are SkillLens AI, a concise, practical career skill coach. Answer the user's question directly using the supplied demo profile context when relevant. Give actionable next steps. Do not promise employment or present simulated readiness as guaranteed. Keep answers under 140 words and use plain text with short paragraphs.",
            },
            {
              role: "user",
              content: `Profile context:\n${input.profileContext ?? "No uploaded profile context is available yet. Answer the question generally and ask for a target role or resume when personalization would materially improve the advice."}\n\nQuestion:\n${input.question}`,
            },
          ],
        });
        const content = response.choices?.[0]?.message?.content;
        const answer = typeof content === "string" ? content : "I couldn't generate a response right now. Try asking about your next skill, biggest gap, roadmap, or a project to build.";
        return { answer };
      }),
  }),
});

export type AppRouter = typeof appRouter;
