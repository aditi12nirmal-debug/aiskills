import { describe, expect, it } from "vitest";
import { jobRelevance, stripHtml } from "./routers";

describe("live job matching helpers", () => {
  it("removes markup and normalizes whitespace from job summaries", () => {
    expect(stripHtml("<p>Build <strong>AI</strong> systems</p>\n for production")).toBe("Build AI systems for production");
  });

  it("scores listings higher when title and description match the target route", () => {
    const strong = jobRelevance("Senior AI Engineer - MLOps", "Build Python model deployment and monitoring systems", "AI Engineer", ["Python", "MLOps"]);
    const weak = jobRelevance("Office Operations Coordinator", "Manage calendars, invoices, and office supplies", "AI Engineer", ["Python", "MLOps"]);
    expect(strong).toBeGreaterThan(weak);
    expect(strong).toBeGreaterThanOrEqual(70);
    expect(weak).toBeLessThan(70);
  });
});
