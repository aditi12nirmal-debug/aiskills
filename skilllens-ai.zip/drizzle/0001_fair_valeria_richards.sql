CREATE TABLE `careerDocuments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`fileName` varchar(255) NOT NULL,
	`mimeType` varchar(160) NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`targetRole` varchar(160) NOT NULL,
	`extractedText` text,
	`analysisJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `careerDocuments_id` PRIMARY KEY(`id`)
);
