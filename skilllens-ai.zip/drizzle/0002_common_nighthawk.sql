CREATE TABLE `resumeComparisons` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`leftDocumentId` int NOT NULL,
	`rightDocumentId` int NOT NULL,
	`targetRole` varchar(160) NOT NULL,
	`resultJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `resumeComparisons_id` PRIMARY KEY(`id`)
);
