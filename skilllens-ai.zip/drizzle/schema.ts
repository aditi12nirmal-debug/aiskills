import { int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** One saved career map per authenticated user. JSON is kept as text so the demo can evolve without migrations. */
export const careerProfiles = mysqlTable("careerProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  name: varchar("name", { length: 160 }).notNull(),
  targetRole: varchar("targetRole", { length: 160 }).notNull(),
  experience: varchar("experience", { length: 80 }).notNull(),
  readinessScore: int("readinessScore").notNull(),
  futureScore: int("futureScore").notNull(),
  skillsJson: text("skillsJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const roadmapProgress = mysqlTable("roadmapProgress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  phaseId: varchar("phaseId", { length: 16 }).notNull(),
  completed: int("completed").notNull().default(0),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userPhaseUnique: uniqueIndex("roadmapProgress_user_phase_idx").on(table.userId, table.phaseId),
}));

export const savedProjects = mysqlTable("savedProjects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  projectId: varchar("projectId", { length: 16 }).notNull(),
  completed: int("completed").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userProjectUnique: uniqueIndex("savedProjects_user_project_idx").on(table.userId, table.projectId),
}));

export const simulatorSessions = mysqlTable("simulatorSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  selectedSkillsJson: text("selectedSkillsJson").notNull(),
  simulatedScore: int("simulatedScore").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const careerDocuments = mysqlTable("careerDocuments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 160 }).notNull(),
  storageKey: varchar("storageKey", { length: 512 }).notNull(),
  targetRole: varchar("targetRole", { length: 160 }).notNull(),
  extractedText: text("extractedText"),
  analysisJson: text("analysisJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const resumeComparisons = mysqlTable("resumeComparisons", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  leftDocumentId: int("leftDocumentId").notNull(),
  rightDocumentId: int("rightDocumentId").notNull(),
  targetRole: varchar("targetRole", { length: 160 }).notNull(),
  resultJson: text("resultJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CareerProfile = typeof careerProfiles.$inferSelect;
export type RoadmapProgress = typeof roadmapProgress.$inferSelect;
export type SavedProject = typeof savedProjects.$inferSelect;
export type CareerDocument = typeof careerDocuments.$inferSelect;
export type ResumeComparison = typeof resumeComparisons.$inferSelect;
